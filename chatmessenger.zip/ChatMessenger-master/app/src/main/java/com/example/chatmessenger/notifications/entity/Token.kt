package com.example.chatmessenger.notifications.entity

data class Token(val token: String? = "") {
}