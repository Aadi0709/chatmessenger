package com.example.chatmessenger.notifications.entity

data class NotificationData(
    val title: String,
    val message: String
)